/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../../node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="/Users/kode/Desktop/KODETECH/Cop/Church Dues Tracker 2/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
